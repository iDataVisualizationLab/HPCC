// Modified by Ngan Nguyen 2019
// Copyright (c) 2012, Kai Chang
// Released under the BSD License: http://opensource.org/licenses/BSD-3-Clause
import Sortable from "sortablejs";


(function (window) {
    window.Sortable = Sortable
})(window);
